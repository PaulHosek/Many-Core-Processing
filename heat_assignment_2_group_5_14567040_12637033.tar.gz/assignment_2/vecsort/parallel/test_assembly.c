//#include <stdio.h>
//#include <omp.h>
//
//int main() {
//#pragma omp parallel
//    {
//#pragma omp single
//        {
//#pragma omp task
//            {
//                printf("Hello ");
//            }
//#pragma omp task
//            {
//                printf("world!");
//            }
//#pragma omp taskwait
//        }
//    }
//    printf("\n");
//    return 0;
//}
